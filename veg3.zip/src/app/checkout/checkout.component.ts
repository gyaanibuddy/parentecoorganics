import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { first,map, catchError} from 'rxjs/operators';
import { FormControl, FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { pipe, Subject, Observable, Subscription  } from 'rxjs';
import { ProductRes, Product } from '../_models/product';
import { UserRes, User } from '../_models/user';
import {  ApiService } from '../_services/api.service';
import { AuthenticationService } from '../_services/authentication.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  user: User ; 
  error :string;
  OrderData:any;
  done = false;
  templateForm : FormGroup;
  address = ["Primary Address","Secondary Address"];
  selectedAddress: any;
  payment = ['paypal', 'card', 'UPI'];
  private subProduct: Subscription ;
  id ;
  obj : any ;
  addressForm: FormGroup ;
  constructor(private route: ActivatedRoute,
        private router: Router,
        private formBuilder: FormBuilder,
        private api: ApiService,
        private authenticationService: AuthenticationService) { 
  	 this.user = this.authenticationService.userValue;
     
  }

  ngOnInit(): void {
    this.id=this.route.snapshot.paramMap.get('oid');
    console.log(this.id);
    const myObserver = {
      next: (res) => this.OrderData= res ,
      err: (err) => {console.log(err)},
      complete: () => console.log('complete fetching data')
     };

    this.subProduct = this.api.checkout(this.id)
      .subscribe(myObserver)

    this.addressForm = this.formBuilder.group({
      addr1: [''],
      addr2: [''],
      city:  [''],
      state: [''],
      postalCode: [''],
    })
  }

   get f() { return this.addressForm.controls; }

  updateAddress(){
    console.log("Hiijrgdk",this.selectedAddress)
    if(this.selectedAddress == "Primary Address"){
      console.log("hiii");
      console.log(this.OrderData);

        this.addressForm.setValue({
              addr1:this.OrderData.data[0].owner.primaryAddress.addr1,
              addr2: this.OrderData.data[0].owner.primaryAddress.addr2,
              city : this.OrderData.data[0].owner.primaryAddress.city,
              state: this.OrderData.data[0].owner.primaryAddress.state,
              postalCode :this.OrderData.data[0].owner.primaryAddress.postalCode
            });
         this.addressForm.disable()
    }
    if(this.selectedAddress == "Secondary Address"){
      console.log("true");
      this.addressForm.reset();
      this.addressForm.enable();
      
      console.log("hiii");
      console.log(this.OrderData.data[0].owner.primaryAddress.addr1);  
    }
  }



  placeOrder(){
    console.log(this.id);
    if(this.selectedAddress == "Primary Address"){
      this.obj = {
        id : this.id,
        delieveryAddress :"primary"
      }
    }
    if(this.selectedAddress == "Secondary Address"){
      this.obj = {
        id : this.id,
        delieveryAddress : "secondary",
        addr1 : this.f.addr1.value,
        addr2 : this.f.addr2.value,
        city : this.f.city.value,
        state : this.f.state.value,
        postalCode : this.f.postalCode.value,
      }
    }
    this.api.placeOrder(this.obj)
      .pipe(first())
            .subscribe(
                data => {
                  // this.loading = false;
                  // this.submitted = false;
                  if(data.success){
                    console.log("success");
                    this.done= true;
                    //this.router.navigate(['/login'])
                  }else{
                    this.error = data.message;
                  }
                    //console.log('data', data);
                    //this.router.navigate([this.returnUrl]);
                },
                error => {
                  console.log("error");
                    // this.error = error;
                    // this.loading = false;
                });

  }

}
