import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { first,map, catchError} from 'rxjs/operators';
import { FormControl, FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { pipe, Subject, Observable, Subscription  } from 'rxjs';
import { ProductRes, Product } from '../_models/product';
import { UserRes, User } from '../_models/user';
import {  ApiService } from '../_services/api.service';
import { AuthenticationService } from '../_services/authentication.service';
@Component({
  selector: 'app-admin-history',
  templateUrl: './admin-history.component.html',
  styleUrls: ['./admin-history.component.css']
})
export class AdminHistoryComponent implements OnInit {
	OrdersData:any[];
	private subOrder: Subscription ;
  error : string ;
  constructor(private route: ActivatedRoute,
        private router: Router,
        private api: ApiService,
        private authenticationService: AuthenticationService) { }

  ngOnInit(): void {
  	this.getPlacedOrders();
  //this.getDelieveredOrders();
  }

  getPlacedOrders(){
  	const myObserver = {
      next: (res) => {
      this.OrdersData= res.data;

      },
      err: (err) => {console.log(err)},
      complete: () => console.log('complete fetching data')
     };

    this.subOrder = this.api.getPlacedOrders()
      .subscribe(myObserver)
  }

  delieverOrder(id : string){

    console.log(id);
   
    this.api.delieverOrder(id)
      .pipe(first())
            .subscribe(
                data => {
                  // this.loading = false;
                  // this.submitted = false;
                  if(data.success){
                    console.log("success");
                    this.getPlacedOrders();
                  }else{
                    this.error = data.message;
                  }
                },
                error => {
                  console.log("error");
                    // this.error = error;
                    // this.loading = false;
                });

  }
}
