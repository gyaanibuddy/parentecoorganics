export class Role1 {
	role: string ;
} 
